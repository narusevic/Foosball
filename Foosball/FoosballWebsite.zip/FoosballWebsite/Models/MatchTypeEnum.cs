namespace FoosballWebsite.Models
{
    public enum MatchTypeEnums {
        Foosball
    }
}
