namespace FoosballWebsite.Models
{
    public class MatchScore
    {
        public int HostScore { get; set; }
        public int GuestScore { get; set; }
    }
}
