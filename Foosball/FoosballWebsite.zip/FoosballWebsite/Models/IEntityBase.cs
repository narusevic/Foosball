namespace FoosballWebsite.Models
{
    public interface IEntityBase
    {
        int Id { get; set; }
    }
}
